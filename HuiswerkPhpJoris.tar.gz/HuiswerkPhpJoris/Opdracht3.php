<?php
/**
 * Author: Joris Rietveld <jorisrietveld@gmail.com>
 * Created: 06-09-2016 13:45
 */
?>
<!DOCTYPE HTML>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Find the mistakes</title>
</head>
<body>
<?php
/*
Joris Rietveld
06-09-2016
*/
echo '<h1>Califoria Occuptional Guide</h2>';
echo '<h2>Locksmiths</h2>';
echo '<p>A locksmith installs, services, and repairs various
types of locks and ... .'
?>
</body>
</html>
