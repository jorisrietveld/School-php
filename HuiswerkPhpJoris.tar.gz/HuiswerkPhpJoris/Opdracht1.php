<!DOCTYPE html>
<html>
<head>
    <title>php Project</title>
</head>
<body>
<?php
/**
 * Author: Joris Rietveld <jorisrietveld@gmail.com>
 * Created: 06-09-2016 13:41
 */
print "<h1>Hello world</h1>";
print "<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>";
?>
</body>
</html>
